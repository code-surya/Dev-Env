
document.addEventListener('keydown', (event) => {
  const webview = document.getElementById('webview');
  if (!webview) return;

  const { ctrlKey, altKey, key } = event;

  // F11 — Fullscreen
  if (key === 'F11') {
    event.preventDefault();
    window.electronAPI.toggleFullscreen();
  }

  // Ctrl+R — Reload webview
  if (ctrlKey && key.toLowerCase() === 'r') {
    event.preventDefault();
    webview.reload();
  }

  // Ctrl+L — Focus address bar
  if (ctrlKey && key.toLowerCase() === 'l') {
    event.preventDefault();
    const input = document.getElementById('url-input');
    input?.focus();
    input?.select();
  }

  // Alt + Left/Right — Back/Forward navigation
  if (altKey && key === 'ArrowLeft') {
    event.preventDefault();
    if (webview.canGoBack()) webview.goBack();
  }

  if (altKey && key === 'ArrowRight') {
    event.preventDefault();
    if (webview.canGoForward()) webview.goForward();
  }

  // Ctrl+T — Placeholder for opening new tab
  if (ctrlKey && key.toLowerCase() === 't') {
    event.preventDefault();
    alert('Ctrl+T pressed (implement tab creation logic)');
  }

  // Ctrl+W — Placeholder for closing current tab
  if (ctrlKey && key.toLowerCase() === 'w') {
    event.preventDefault();
    alert('Ctrl+W pressed (implement tab close logic)');
  }
});
