document.addEventListener('DOMContentLoaded', () => {
  const popup = document.getElementById('tab-popup');
  const list = document.getElementById('tab-list');
  let currentIndex = 0;
  let tabData = [];

  function showPopup() {
    popup.classList.remove('hidden');
    window.wq.requestTabs().then(tabs => {
      tabData = tabs;
      list.innerHTML = '';
      tabs.forEach((tab, i) => {
        const li = document.createElement('li');
        li.textContent = tab.title || tab.url;
        if (i === 0) li.classList.add('selected');
        list.appendChild(li);
      });
    });
  }

  function hidePopup() {
    popup.classList.add('hidden');
  }

  function updateSelection() {
    [...list.children].forEach((li, i) => {
      li.classList.toggle('selected', i === currentIndex);
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key.toLowerCase() === 'b') {
      showPopup();
    } else if (!popup.classList.contains('hidden')) {
      if (e.key === 'j') {
        currentIndex = (currentIndex + 1) % tabData.length;
        updateSelection();
      } else if (e.key === 'k') {
        currentIndex = (currentIndex - 1 + tabData.length) % tabData.length;
        updateSelection();
      } else if (e.key === 'Enter') {
        window.wq.switchTab(tabData[currentIndex].id);
        hidePopup();
      } else if (e.key === 'Escape') {
        hidePopup();
      }
    }
  });
});

